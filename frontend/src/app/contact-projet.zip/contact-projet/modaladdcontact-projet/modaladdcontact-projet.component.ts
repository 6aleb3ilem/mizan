import { Component, OnInit,Input } from '@angular/core';
import { Contact } from 'src/app/contact/contact';
import { ContactService } from 'src/app/contact/contact.service';
import { Client } from 'src/app/tache/client';
import { ContactProjetService } from '../contact-projet.service';
@Component({
  selector: 'app-modaladdcontact-projet',
  templateUrl: './modaladdcontact-projet.component.html',
  styleUrls: ['./modaladdcontact-projet.component.css']
})
export class ModaladdcontactProjetComponent implements OnInit {
  contacts: Contact[] = [];
  selectedProjectId: number | null = null; // Supposons que vous ayez un moyen de définir ceci, par exemple, via une sélection dans l'interface utilisateur
  client: Client | null = null;
  @Input() projectId: number | null = null;

  constructor(private contactService: ContactService,private contactProjetService: ContactProjetService) { }

 
  ngOnInit() {
    console.log("Project ID:", this.projectId); // Pour déboguer

    this.loadContacts();
    if (this.projectId) {
      this.loadClientForProject(this.projectId);
      
    }
  }

  loadContacts(): void {
    this.contactService.getAllContacts().subscribe({
      next: (data) => this.contacts = data,
      error: (err) => console.error('Erreur lors de la récupération des contacts', err)
    });
  }

  loadClientForProject(projectId: number): void {
    this.contactProjetService.getClientByProjectId(projectId).subscribe({
      next: (client) => this.client = client,
      error: (err) => console.error('Erreur lors de la récupération du client', err)
    });
  }

  closeModal() {
    const modalBackground = document.getElementById('modalBackground');
    if (modalBackground) {
      modalBackground.style.display = 'none';
    }
  }

}
