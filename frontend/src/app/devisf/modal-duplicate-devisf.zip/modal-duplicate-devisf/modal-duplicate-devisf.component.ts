// modal-duplicate-devisf.component.ts

import { Component, OnInit, Input } from '@angular/core';
import { Project } from 'src/app/projets/project';
import { ProjectService } from 'src/app/projets/project.service';
import { DevisfService } from '../devisf.service';
@Component({
  selector: 'app-modal-duplicate-devisf',
  templateUrl: './modal-duplicate-devisf.component.html',
  styleUrls: ['./modal-duplicate-devisf.component.css']
})
export class ModalDuplicateDevisfComponent implements OnInit {
  selectedProjectId?: number; // Déclarez la propriété selectedProjectId
  projects?: Project[]; // Déclarez la propriété projects
  @Input() selectedDevisId: number | null = null;
  constructor(private projectService: ProjectService,private DevisfService: DevisfService) { }

  ngOnInit(): void {
    this.projectService.getAllProjects().subscribe(projects => {
      this.projects = projects;
    });
  }


closeModalDupplicate(){
  const modalBackgroundupplicate = document.getElementById('modalBackgroundupplicate');
  if (modalBackgroundupplicate) {
    modalBackgroundupplicate.style.display = 'none';
  }

}
duplicateDevis() {
  if (this.selectedDevisId && this.selectedProjectId) {
    this.DevisfService.collerDevis(this.selectedDevisId, this.selectedProjectId).subscribe(copie => {
      console.log('Copie du devis:', copie);
      this.closeModalDupplicate();
    });
  }
}
}